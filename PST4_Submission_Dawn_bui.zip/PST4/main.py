# main.py - GUI Launcher
import sys
sys.path.append('C:/Users/Admin/Desktop/FIT1056-Sem2-2025-new/PST4/gui')
from main_dashboard import launch

if __name__ == "__main__":
    # This file's only job is to start the GUI.
    launch()