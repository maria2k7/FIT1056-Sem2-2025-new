import sys
import json
import csv
import logging
import datetime
sys.path.append('C:/Users/Admin/Desktop/FIT1056-Sem2-2025-new/PST5/app')
from student import StudentUser
from teacher import TeacherUser, Course
logging.basicConfig(
    filename="C:/Users/Admin/Desktop/FIT1056-Sem2-2025-new/PST5/data/system.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
class ScheduleManager:
    """The main controller for all business logic and data handling."""
    def __init__(self, data_path="C:/Users/Admin/Desktop/FIT1056-Sem2-2025-new/PST4/data/msms.json"):
        self.data_path = data_path
        self.students = []
        self.teachers = []
        self.courses = []
        # TODO: Initialize the new attendance_log attribute as an empty list.
        self.attendance_log = []
        self.finance_log = []
        # ... (next_id counters) ...
        self._load_data()

    def _load_data(self):
        """Loads data from the JSON file and populates the object lists."""
        try:
            with open(self.data_path, 'r') as f:
                data = json.load(f)
                # TODO: Load students, teachers, and courses as before.
                # ...
                self.students = [StudentUser(**s) for s in data.get("students",[])]
                self.teachers = [TeacherUser(**s) for s in data.get("teachers",[])]
                self.courses = [Course(**c) for c in data.get("courses",[])]
                # TODO: Correctly load the attendance log.
                # Use .get() with a default empty list to prevent errors if the key doesn't exist.
                self.attendance_log = data.get("attendance", [])
                self.finance_log = data.get("finance", []) 
                print ("The data has been retrieved successfully")
                return data
        except FileNotFoundError:
            print("Data file not found. Starting with a clean state.")
            return {"students": [], "teachers": [], "courses": [], "attendance": [], "finance": []}    
    def _save_data(self):
        """Converts object lists back to dictionaries and saves to JSON."""
        # TODO: Create a 'data_to_save' dictionary.
        data_to_save = {
            "students": [s.__dict__ for s in self.students],
            "teachers": [t.__dict__ for t in self.teachers],
            "courses": [c.__dict__ for c in self.courses],
            # TODO: Add the attendance_log to the dictionary to be saved.
            # Since it's already a list of dicts, no conversion is needed.
            "attendance": self.attendance_log,
            "finance": self.finance_log,
            # ... (next_id counters) ...
        }
        # TODO: Write 'data_to_save' to the JSON file.
        with open(self.data_path, 'w') as f:
            json.dump(data_to_save, f, indent=4)
    def check_in(self, student_id, course_id):
        self._load_data()
        """Records a student's attendance for a course after validation."""
        # This implementation remains the same, but it will now function correctly.
        student = next((s for s in self.students if getattr(s, 'id', getattr(s, 'user_id', None)) == int(student_id)), None)
        course = next((c for c in self.courses if getattr(c, 'id', getattr(c, 'course_id', None)) == int(course_id)), None)
        enrolled_courses = getattr(student, 'enrolled_course_ids', [])
        
        if not student or not course:
            print("Error: Check-in failed. Invalid Student or Course ID.")
            return False

        if getattr(course, 'id', getattr(course, 'course_id', None)) not in enrolled_courses:
            print(f"This student is not enrolled in {course.name}.")
            return False
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        check_in_record = {
            "student_id": int(student_id),
            "course_id": int(course_id),
            "timestamp": now
        }

        # This line will now work without causing an AttributeError.
        self.attendance_log.append(check_in_record)
        self._save_data() # This will now correctly save the attendance log.
        print(f"Success: Student {student.name} checked into {course.name}.")
        return True

    def find_student_by_id(self, user_id):
        try:
            user_id = int(user_id)
        except ValueError:
            return None
        for student in self.students:
            if getattr(student, 'user_id', None) == user_id:
                return student
        return None
    def find_student_by_name(self, name):
        for s in self.students:
            if s.name.lower() == name.lower():
                return s
        return None
    def find_course_by_id(self, course_id):
        for course in self.courses:
            if getattr(course, 'course_id', None) == course_id:
                return course
        return None 
    def register_new_student(self, student_name, course_name):
        self._load_data()
        new_id = max ([s.id for s in self.students], default=0) + 1
        enrolled_course = next((c for c in self.courses if c.name == course_name), None)
        if not enrolled_course:
            raise ValueError (f"Course {course_name} does not exist.")
        new_student = StudentUser(id=new_id, name=student_name, enrolled_course_ids=[enrolled_course.id])
        self.students. append(new_student)
        self._save_data()
        print("done!")
        return new_student
    # # TODO: Also implement find_student_by_id and find_course_by_id helper methods.
    def record_payment(self, student_id, amount, method):
        """Record a payment and log it."""
        student = self.find_student_by_id(student_id)
        if not student:
            print("Error: Student not found.")
            return False

        payment_record = {
            "student_id": student_id,
            "amount": amount,
            "method": method,
            "timestamp": datetime.datetime.now().isoformat()
        }
        self.finance_log.append(payment_record)
        self._save_data()
        logging.info(f"Payment of {amount} recorded for student ID {student_id}.")
        print(f"Payment of {amount} for {student.name} recorded.")
        return True

    def get_payment_history(self, student_id):
        """Returns a list of all payments for a given student."""
        # TODO: Use a list comprehension to filter self.finance_log
        # and return only the records that match the student_id.
        return [p for p in self.finance_log if p['student_id'] == student_id]

    def export_report(self, kind, out_path):
        """Exports a log to a CSV file."""
        print(f"Exporting {kind} report to {out_path}...")
        # TODO: Use an if/elif block to select the correct data list based on 'kind'.
        if kind == "finance":
            data_to_export = self.finance_log
            headers = ["student_id", "amount", "method", "timestamp"]
        elif kind == "attendance":
            data_to_export = self.attendance_log # Assuming this exists from PST2
            headers = ["student_id", "course_id", "timestamp"]
        else:
            print("Error: Unknown report type.")
            return
        with open(out_path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            writer.writerows(data_to_export)

    def cancel_lesson(self, lesson_id, reason):
        # ... (logic to cancel a lesson) ...
        self._save_data()
        # TODO: Add a log entry.
        logging.warning(f"Lesson ID {lesson_id} was cancelled. Reason: {reason}")
        # TODO: Use Python's 'csv' module to write the data.
        # Open the file, create a csv.DictWriter, write the header, then write all the rows.